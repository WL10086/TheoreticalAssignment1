import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Vector;
import java.io.FileOutputStream;
import java.util.Date;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFDataFormat;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFHyperlink;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.extractor.ExcelExtractor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;

public class TheoreticalHomework2 {
	static Workbook openWorkbook(InputStream in, String fileame,
			String fileFileName) throws IOException {
		Workbook wb = null;
		if (fileFileName.endsWith("xlsx")) {
			wb = new HSSFWorkbook(in);// excel2007
		} else {
			wb = (Workbook) new HSSFWorkbook(in);// excel2003
		}
		return wb;
	}

	public static void sort(float[] f) {
		float temp = (float) 0.0;
		for (int i = 0; i < f.length; i++) {
			for (int j = i + 1; j < f.length; j++) {
				if (f[j] > f[i]) {
					temp = f[j];
					f[j] = f[i];
					f[i] = temp;
				}
			}
		}

	}

	public static List<String[]> getExcelData(String fileName,
			String fileFielName) throws Exception {
		InputStream in = new FileInputStream(fileName);
		Workbook wb = openWorkbook(in, fileName, fileFielName);
		Sheet sheet = wb.getSheetAt(0);
		List<String[]> list = new ArrayList<String[]>();
		Row row = null;
		Cell cell = null;
		int totalRows = sheet.getPhysicalNumberOfRows();// ������
		int totalCells = sheet.getRow(0).getPhysicalNumberOfCells();// ��
		float[] xf = new float[totalRows - 1];
		float[] grade0 = new float[totalRows - 1];
		float[] gpa1 = { (float) 4.0, (float) 3.7, (float) 3.3, (float) 3.0,
				(float) 2.7, (float) 2.3, (float) 2.0, };
		float[] gradegpa = new float[totalRows];
		float gradexf[] = new float[totalRows];
		float sum0 = 0;
		float sum1 = 0;
		float sum10 = 0;
		for (int i = 0; i < totalRows - 1; i++) {
			grade0[i] = Float.parseFloat(sheet.getRow(i + 1).getCell(9)
					.toString());
		}
		for (int i = 0; i < totalRows - 1; i++) {
			xf[i] = Float.parseFloat(sheet.getRow(i + 1).getCell(3).toString());
		}
		for (int i = 0; i < totalCells; i++) {
			if (grade0[i] >= 90) {
				gradegpa[i] = gpa1[0] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 85 && grade0[i] <= 89) {
				gradegpa[i] = gpa1[1] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 82 && grade0[i] <= 84) {
				gradegpa[i] = gpa1[2] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 78 && grade0[i] <= 81) {
				gradegpa[i] = gpa1[3] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 75 && grade0[i] <= 77) {
				gradegpa[i] = gpa1[4] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 72 && grade0[i] <= 74) {
				gradegpa[i] = gpa1[5] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			} else if (grade0[i] >= 67 && grade0[i] <= 71) {
				gradegpa[i] = gpa1[6] * xf[i];
				gradexf[i] = grade0[i] * xf[i];
			}
			sum0 = sum0 + gradegpa[i];
			sum1 = sum1 + gradexf[i];
			sum10 = sum10 + xf[i];
		}
		sort(grade0);
		HSSFWorkbook aHssfWorkbook2 = new HSSFWorkbook();
		HSSFSheet aHssfSheet = aHssfWorkbook2.createSheet("wl");
		Vector<HSSFRow> aHssfRows = new Vector<HSSFRow>();
		aHssfRows.add(aHssfSheet.createRow(0));
		for (int i = 0; i < 10; i++) {
			aHssfRows.get(0).createCell((short) i)
					.setCellValue(sheet.getRow(0).getCell(i).toString());
		}
		for (int i = 0; i < totalRows - 1; i++) {
			aHssfRows.add(aHssfSheet.createRow(i + 1));
		}

		for (int r = 0; r < totalRows - 1; r++) {
			row = sheet.getRow(r);
			for (int c = 0; c < totalRows - 1; c++) {
				if (Float.parseFloat(sheet.getRow(r + 1).getCell(9).toString()) == grade0[c]) {
					for (int h = 0; h < 10; h++) {
						aHssfRows
								.get(r + 1)
								.createCell((short) h)
								.setCellValue(
										sheet.getRow(r + 1).getCell(h)
												.toString());
					}
					grade0[c] = -1;

				}

				String cellValue = "";
				if (null != cell) {
					switch (cell.getCellType()) {
					case HSSFCell.CELL_TYPE_NUMERIC:
						cellValue = cell.getNumericCellValue() + "";
						break;
					case HSSFCell.CELL_TYPE_STRING:
						cellValue = cell.getStringCellValue();
						break;
					case HSSFCell.CELL_TYPE_BOOLEAN:
						cellValue = cell.getBooleanCellValue() + "";
						break;
					case HSSFCell.CELL_TYPE_FORMULA:
						cellValue = cell.getCellFormula() + "";
						break;
					case HSSFCell.CELL_TYPE_BLANK:
						cellValue = "";
						break;
					case HSSFCell.CELL_TYPE_ERROR:
						cellValue = "�Ƿ��ַ�";
						break;
					default:
						cellValue = "δ֪����";
						break;
					}

				}

			}

		}

		aHssfRows.get(0).createCell((short) 10).setCellValue("��Ȩƽ����");
		aHssfRows.get(0).createCell((short) 11).setCellValue("����");
		aHssfRows.get(1).createCell((short) 10).setCellValue(sum1 / sum10);
		aHssfRows.get(1).createCell((short) 11).setCellValue(sum0 / sum10);
		String filename = "C:/Users/Administrator/Desktop/grade10.xls";
		FileOutputStream fout = new FileOutputStream(filename);
		aHssfWorkbook2.write(fout);
		fout.flush();
		return list;
	}

	public static void main(String[] args) throws Exception {
		String fileName = "C:/Users/Administrator/Desktop/grade1.xls";
		TheoreticalHomework2 theoreticalHomework2 = new TheoreticalHomework2();
		theoreticalHomework2.getExcelData(fileName, "xls");

		// HSSFWorkbook wb = new HSSFWorkbook();

	}

}
